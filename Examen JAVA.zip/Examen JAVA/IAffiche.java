public interface IAffiche{
    public String affiche();
    public void compare();
}